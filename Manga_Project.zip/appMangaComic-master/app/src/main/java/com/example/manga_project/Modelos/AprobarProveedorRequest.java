package com.example.manga_project.Modelos;

public class AprobarProveedorRequest {
    private int id_user;

    public AprobarProveedorRequest(int id_user) {
        this.id_user = id_user;
    }

    public int getId_user() {
        return id_user;
    }
}
