package com.example.manga_project;

public interface Logout {
    void logout();
}
