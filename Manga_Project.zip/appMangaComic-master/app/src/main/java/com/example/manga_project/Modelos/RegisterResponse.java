package com.example.manga_project.Modelos;

public class RegisterResponse {
    private String message;

    public String getMessage() {
        return message;
    }
}