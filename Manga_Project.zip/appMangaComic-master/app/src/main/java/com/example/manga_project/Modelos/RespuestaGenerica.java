package com.example.manga_project.Modelos;

public class RespuestaGenerica {
    public int code;
    public String msg;
}

