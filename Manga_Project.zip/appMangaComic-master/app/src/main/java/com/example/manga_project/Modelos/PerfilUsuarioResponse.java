package com.example.manga_project.Modelos;

public class PerfilUsuarioResponse {
    public boolean success;
    public PerfilResponse data;
}
