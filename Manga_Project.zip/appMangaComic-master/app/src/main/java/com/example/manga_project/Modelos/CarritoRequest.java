package com.example.manga_project.Modelos;

public class CarritoRequest {
    public int id_volumen;
    public int cantidad;

    public CarritoRequest(int id_volumen, int cantidad) {
        this.id_volumen = id_volumen;
        this.cantidad = cantidad;
    }
}
