package com.example.manga_project.Modelos;

public class Comentario {
    public String usuario;
    public String fecha;
    public String texto;

    public Comentario(String usuario, String fecha, String texto) {
        this.usuario = usuario;
        this.fecha = fecha;
        this.texto = texto;
    }
}

