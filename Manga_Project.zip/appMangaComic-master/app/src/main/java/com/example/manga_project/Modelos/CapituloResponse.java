package com.example.manga_project.Modelos;

import java.util.List;

public class CapituloResponse {
    public int code;
    public List<String> chapters;
}

