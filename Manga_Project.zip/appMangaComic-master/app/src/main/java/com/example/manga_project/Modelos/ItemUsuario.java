package com.example.manga_project.Modelos;

public class ItemUsuario {
    public int id;
    public String portada;
    public String titulo;
    public String autores;
    public String fecha;
    public boolean esWishlist = false;
    public int id_volumen;
}
