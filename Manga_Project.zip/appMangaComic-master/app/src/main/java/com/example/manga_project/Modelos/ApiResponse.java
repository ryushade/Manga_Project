package com.example.manga_project.Modelos;

public class ApiResponse<T> {
    public boolean success;
    public T data;
}
