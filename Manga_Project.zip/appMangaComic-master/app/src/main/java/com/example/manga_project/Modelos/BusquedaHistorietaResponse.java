package com.example.manga_project.Modelos;

import java.util.List;

public class BusquedaHistorietaResponse {
    public boolean success;
    public List<BusquedaHistorieta> data;
    public String message;
}

