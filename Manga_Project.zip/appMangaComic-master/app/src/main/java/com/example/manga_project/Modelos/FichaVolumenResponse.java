package com.example.manga_project.Modelos;

public class FichaVolumenResponse {
    public int id_volumen;
    public String titulo;
    public String sinopsis;
    public String portada;
    public double precio;
    public String anio;
    public String tipo;
}

