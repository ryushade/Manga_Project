package com.example.manga_project.Modelos;

public class SolicitudPublicacionResponse {
    private int code;
    private String msg;

    public int getCode() { return code; }
    public String getMsg() { return msg; }
}
