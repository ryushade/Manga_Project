package com.example.manga_project.Modelos;

public class BusquedaHistorieta {
    public int id_historieta;
    public String titulo;
    public String descripcion;
    public String portada_url;
    public String tipo;
}

