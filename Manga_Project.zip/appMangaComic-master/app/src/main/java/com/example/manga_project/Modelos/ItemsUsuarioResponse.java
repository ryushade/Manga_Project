package com.example.manga_project.Modelos;

import java.util.List;

public class ItemsUsuarioResponse {
    public boolean success;
    public String type;
    public List<ItemUsuario> data;
}
