package com.example.manga_project.Api_cliente;

public class PaymentIntentRequest {
    public int amount;
    public PaymentIntentRequest(int amount) {
        this.amount = amount;
    }
}
