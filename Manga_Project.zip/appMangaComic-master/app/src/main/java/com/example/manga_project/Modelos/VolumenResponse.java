package com.example.manga_project.Modelos;

public class VolumenResponse {
    public int id_volumen;
    public String titulo;
    public String portada;
    public double precio;
    public String anio;
    // Puedes agregar más campos si tu backend los retorna
}

