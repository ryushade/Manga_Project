package com.example.manga_project.Api_cliente;

public class PaymentIntentResponse {
    public String clientSecret;
}
