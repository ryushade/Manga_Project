package com.example.manga_project.fragments;

public class HistorietasFragment {
}
