package com.example.manga_project.Modelos;

import java.util.List;

public class CrearComentarioResponse {
    public int id_comentario;
    public List<Comentario> comentarios;
}

